import React from "react";
import { createRoot } from "react-dom/client";
import Home from "../app/page";
import "../app/globals.css";
import "../app/login.css";

if (typeof document !== "undefined") {
  createRoot(document.getElementById("root")!).render(<Home />);
}

